ELORA NOX — راه‌اندازی

1) Firebase Console → Authentication → Sign-in method
   - Google را Enable کن.
   - Phone را Enable کن.
   - دامنه سایت GitHub Pages را در Authorized domains داشته باش.

2) Firebase Console → Firestore Database
   - Create database
   - Rules را با firestore.rules این پروژه جایگزین کن.

3) Firebase Console → Storage
   - Get started
   - Rules را با storage.rules این پروژه جایگزین کن.

4) یک بار با Google یا SMS وارد سایت شو.
   - UID حساب را از Firebase Console → Authentication → Users کپی کن.
   - در index.html مقدار YOUR_ADMIN_UID را با آن UID عوض کن.
   - همان UID را در firestore.rules و storage.rules هم جایگزین کن.

5) فایل index.html را روی GitHub Pages بگذار.

ساختار Firestore:
products/
  name, price, stock, category, description, imageUrl, storagePath, createdAt, createdBy

orders/
  userId, email, phoneAuth, customerName, customerPhone, address,
  products, total, status, createdAt

نکته:
- کلید apiKey موجود در firebaseConfig یک Secret نیست و در سایت وب قابل نمایش است.
- امنیت واقعی با Firestore/Storage Rules انجام می‌شود؛ ADMIN_UID را در هر سه فایل تنظیم کن.
- Phone Authentication برای وب از reCAPTCHA استفاده می‌کند.
